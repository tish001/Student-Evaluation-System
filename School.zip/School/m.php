<?php
	include"database.php";
	
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label>Teacher ID:</label><br>
					<select name="TID" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT TID FROM  teacher order by TID ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["TID"]}'>{$ro["TID"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					
					<div class="lbox1">	
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT(SCLASS) FROM attendance  ";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>
						
				</div>
				<div class="rbox">
					<label>Section</label><br>
						<select name="sec" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(SSEC) FROM attendance order by SSEC ASC";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["SSEC"]}'>{$r["SSEC"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				
				</div>
					<button type="submit" class="btn" name="view"> View Details</button>
				
						
					</form>
					<br>
					
					<div class="Output">
							
                   
        
		<?php
							if(isset($_POST["view"]))
							{
                                ?>
                                <center>
							<h2>MARK SHEET</h2><br>
							<h3>YEAR:</h3>
	
								   
								   
                        <center>
								<?php
							
                               
								$sql="select ID,NAME,TID,TSUB,SSEC,SCLASS,ROUND(((ROUND((SUM(CASE WHEN P_A = 'present' THEN 1 ELSE 0 END)/COUNT(*)*100),2))/100)*5,2) as pmark from attendance  natural join student natural join teacher where SCLASS='{$_POST["cla"]}' and SSEC='{$_POST["sec"]}' and
								TID='{$_POST["TID"]}'group by ID";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
 
									echo '
										<table border="2px">
										<thead>
										<tr>
										<th>SL</th>
											<th>ID</th>
											<th>Name</th>
											<th>MID1</th>
											<th>QUIZ1</th>
											<th>MID2</th>
											<th>QUIZ1</th>
											<th>FINAL</th>
											<th>QUIZ3</th>
											<th>CLASSWORK</th>
										</tr>
										<thead>
									
									
									';
            $i=0;
            while($row = $re->fetch_array()){
				?>
                 <form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                 
                <tr>
			
                <td><?php echo($i)+(1);?></td>
						<td><?php echo($row['ID']);?></td>
						
                <input type="hidden" value="<?php echo $row['ID']; ?>" name="ID[]" id=ID >
				 <input type="hidden" value="<?php echo $row['TID']; ?>"name="TID[]" id="TID[]"></td>
				 <input type="hidden" value="<?php echo $row['TSUB']; ?>"name="TSUB[]" id="TSUB[]"></td>
				 <input type="hidden" value="<?php echo $row['SSEC']; ?>"name="SSEC[]" id="SSEC[]"></td>
				 <input type="hidden" value="<?php echo $row['SCLASS']; ?>"name="SCLASS[]" id="SCLASS[]"></td>
			
				<td><?php echo $row['NAME'];?></td>
				
                <input type="hidden" value="<?php echo $row['NAME']; ?>" name="NAME[]" >
				<input type="hidden" value="<?php echo $row['pmark']; ?>" name="pmark[]" >
			   <td> <input type="text" name="m1[]" id="m1[]" size="10"color: blue ></td>
			   <td> <input type="text" name="q1[]" id="q1[]" size="10" color: blue></td>
		  <td><input type="text" name="m2[]" id="m2[]" size="10" color: blue></td>
		  <td> <input type="text" name="q2[]" id="q2[]" size="10" color: blue></td>
		 <td> <input type="text" name="final[]"  id="final[]" size="10"color: blue></td>
		 <td> <input type="text" name="q3[]" id="q3[]"size="10" color: blue></td>
		 <td> <input type="text" name="clw[]" id="clw[]"size="10" color: blue></td>
        
		 
		 
		
            

            <?php $i++;
            }
		   ?>
		    <input type="text" name="year" placeholder="2019" id="year"><br><br>
								</div>
           <?php
		}
		else
							{
								echo "No record Found";
							}
								echo "</table>";
							}
	

        ?>
        <input type="submit" name="submit" class="btn btn-primary " value="submit" >

<?php
if(isset($_POST['submit']))
{
	
	
	foreach($_POST['ID'] as $id => $ID) {
		$FULLMARK=0;
		$m1=0;
		$m2=0;
		$final=0;
		$q1=0;
		$q2=0;
		$q3=0;
		$clw=0;
		
		$ID= $_POST['ID'][$id];
		$NAME= $_POST['NAME'][$id];
		$m1=((float)$_POST['m1'][$id])*25.0/40.0;
		$m2=((float)$_POST['m2'][$id])*25.0/40.0;
		$final=((float)$_POST['final'][$id])*25.0/40.0;
		$q1=((float)$_POST['q1'][$id])*5.0/10.0;
		$q2=((float)$_POST['q2'][$id])*5.0/10.0;
		$q3=((float)$_POST['q3'][$id])*5.0/10.0;
		$clw=(float)$_POST['clw'][$id];
		$year=(float)$_POST['year'];
		$pmark=(float)$_POST['pmark'][$id];
		$TID=$_POST['TID'][$id];
		$TSUB=$_POST['TSUB'][$id];
		$SSEC=$_POST['SSEC'][$id];
        $SCLASS=$_POST['SCLASS'][$id];
	  $FULLMARK=(float)($m1+$m2+$final+$q1+$q2+$q3+$clw+$pmark);
	  //echo $FULLMARK;

	  if($FULLMARK>=90){
		$grade="A+";
	  }
	  elseif($FULLMARK>=80){
		$grade="A";
	  }
	  elseif($FULLMARK>=70){
		$grade="B";
	  }
	  elseif($FULLMARK>=60){
		$grade="C";
	  }
	  elseif($FULLMARK>=50){
		$grade="D";
	  }
	  else{
		$grade="F";

	  }
		/*switch($FULLMARK)
		{
	case($FULLMARK>=90):
		$grade='A';
	break;
	case($FULLMARK>=80):
		$grade='B';
	break;
	case($FULLMARK>=70):
		$grade='C';
	break;
	case($FULLMARK>=60):
		$grade='D';
	break;
	case($FULLMARK>=50):
		$grade='F';
	break;

};*/



	  $sql1= "INSERT INTO mark(ID, NAME,MID1,MID2,FINAL,Attendance,quiz1,quiz2,quiz3,classwork,year,TID,TSUB,SSEC,SCLASS,FULLMARKS,grade)
	  VALUES ('$ID', '$NAME','$m1','$m2','$final','$pmark','$q1','$q2','$q3','$clw','$year','$TID','$TSUB','$SSEC','$SCLASS','$FULLMARK','$grade')";

    $conn = mysqli_connect('localhost','root','','evaluation');
    if(mysqli_query($conn, $sql1)){
		echo nl2br ("Records updated successfully \n");
	}
	 else{
		//echo nl2br("\n Attendance already been taken for  '$NAME! for the $date") ;
        echo "error";
    }
    

    }
    


}


    ?>

                        </form>
        

    </table>
									
</html>

