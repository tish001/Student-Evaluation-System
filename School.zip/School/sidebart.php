<div class="sidebar"><br>
		<h3 class="text">Dashboard</h3><br><hr><br>
		<ul class="s">
		<?php
			if(isset($_SESSION["TID"]))
			{
				echo'
					<li class="li"><a href="take.php"> Add Attendance</a></li>
					<li class="li"><a href="update1.php"> Update Attendance</a></li>
					<li class="li"><a href="atten_view.php">View Attendance</a></li>
					<li class="li"><a href="detail.php">Student-wise Attendance</a></li>
					<li class="li"><a href="m.php">Add Mark</a></li>
					<li class="li"><a href="updatemark.php">Update Mark</a></li>
					<li class="li"><a href="tmark.php">Gradesheet</a></li>

					<li class="li"><a href="logout.php">Logout</a></li>

				';


			}
			


		?>


		</ul>

</div>
