<?php
	include"database.php";
	session_start();
	
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
		<div>
					<br><h1>View Attendence Details</h1><br>
</div>
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					
					<table>
					<tr>
					<div class="lbox1">	
					
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT SCLASS  FROM  student natural JOIN attendance order by SCLASS ASC;";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
								</tr>
					<br><br>	
				
				</div>
				<tr>
				<div class="lbox1">	
						<label>SECTION</label><br>
					<select name="sec" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT SSEC  FROM  student natural JOIN attendance order by SSEC ASC;";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SSEC"]}'>{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>			
				<div class="rbox">
					<label>DATE</label><br>
						<select name="date" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(date) FROM attendance order by date ASC";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["date"]}'>{$r["date"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				</div>
								</tr>
				<tr><div class="rbox">
			<button type="submit" class="btn" name="view"> View</button>
			<br><br>
						</div>	
						
								</tr>		
					</table>	
				</form>
					
					<div>
					<center>
			
						
					
						<?php
						
							if(isset($_POST["view"]))
							{
?>


					
							<?php
							
								$sql="select * from attendance natural join student where SCLASS ='{$_POST["cla"]}'and SSEC='{$_POST["sec"]}' and date='{$_POST["date"]}' ";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
									echo '
								
										<table border="1px">
										
										<tr>
										
											<th>ID</th>
											<th>NAME</th>
											<th>EMAIL ID</th>
											<th>CLASS</th>
											<th>SECTION</th>
											<th>ATTENDENCE STATUS</th>
											<th>DATE</th>
										</tr>
									
									
									';
									$i=0;
									while($r=$re->fetch_assoc())
									{
										$i++;
										echo "
										<tr>
											
											<td>{$r["ID"]}</td>
											<td>{$r["NAME"]}</td>
											<td>{$r["MAIL"]}</td>
											<td>{$r["SCLASS"]}</td>
											<td>{$r["SSEC"]}</td>
											<td>{$r["P_A"]}</td>
											<td>{$r["date"]}</td>
											
</tr>
										";
									
										
										$i++;
									}
								}
							else
							{
							
								echo "No record found";
								
								
							}
								
							}
						
						
						?>
						
					
						</center>
						</table>
					
	</body>
</html>





