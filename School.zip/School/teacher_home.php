<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";
		
	}	
	
	
	$sql="SELECT * FROM teacher WHERE TID={$_SESSION["TID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Student Evaluation System</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include"navbar.php";?><br>
	
			<div id="section">
				<?php include"sidebart.php";?><br>
					<h3 class="text">Welcome <?php echo $_SESSION["TNAME"]; ?></h3><br><hr><br>
				<div class="content">
				
					<h3>Add Profile</h3><br>
					<div class="lbox1">
					<?php
						if(isset($_POST["submit"]))
						{
							
								$sql="update teacher set TNAME='{$_POST["tname"]}',TMAIL='{$_POST["tmail"]}',TPASS='{$_POST["pass"]}' where TID={$_SESSION["TID"]}";
								$db->query($sql);
								echo "<div class='success'>Insert Success</div>";
							}
							
						
					
					
					?>
					
					
					
					
						
					<form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
							<label>  NAME</label><br>
							<input type="text" maxlength="10" required class="input3" name="tname"><br><br>
							<label>  MAIL</label><br>
							<input type="email"  class="input3" required name="tmail"><br><br>
							<label>  PASSWORD</label><br>
							<input type="password"  class="input3" required name="pass"><br><br>
							
						<button type="submit" class="btn" name="submit">Add Profile Details</button>
						</form>
					</div>
					
					
					
					
					<div class="rbox1">
					<h3> Profile</h3><br>
						<table border="1px">
	
							<tr><th>Name </th> <td><?php echo $row["TNAME"] ?> </td></tr>
							<tr><th>Mail</th> <td><?php echo $row["TMAIL"] ?>  </td></tr>
							<tr><th>SUBJECT</th> <td> <?php echo $row["TSUB"] ?> </td></tr>
						</table>
					</div>
				</div>
			</div>
	
				
	</body>
</html>