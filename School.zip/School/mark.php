<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["TID"]))
	{
		echo"<script>window.open('teacher_login.php?mes=Access Denied...','_self');</script>";

	}

	if(isset($_GET["cl_id"]) and isset($_GET["sub_id"]) and isset($_GET["exam_type"]) and isset($_GET["year"]))
	{
		$sql="select * from exam where Sub_ID='{$_GET["sub_id"]}' and ETYPE = '{$_GET["exam_type"]}' and Year = '{$_GET["year"]}' and CLASS = ANY (select CNAME from class where CID = '{$_GET["cl_id"]}')";
		$res=$db->query($sql);
		if($res->num_rows<=0)
		{
			header("location:add_mark.php?err=Invalid Register no..");
		}
		else
		{

			$rows=$res->fetch_assoc();
			$class_id=$_GET["cl_id"];
			$exam_id=$rows["EID"];
			$sub_id=$_GET["sub_id"];
			$e_type = $_GET["exam_type"];


		}
	}
	else{
		header("location:add_mark.php?err=Set values..");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Tutor Joe's</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include"navbar.php";?><br>

			<div id="section">
				<?php include"sidebar.php";?><br>
					<h3 class="text">Welcome <?php echo $_SESSION["TNAME"]; ?></h3><br><hr><br>
				<div class="content">

					<h3>Add Marks</h3><br>
					<?php

						if(isset($_POST["submit"]))
						{
							$is_success = true;
							$sql="select * from student where CID = '{$class_id}'";
							$res=$db->query($sql);
							if($res->num_rows>0)
							{
								while($ro=$res->fetch_assoc())
								{
									$stu_id=$ro["ID"];
									$stu_roll=$ro["RNO"];
									$sq="insert into result (EID,CID,SID,STU_ID,MARKS,EVAL) values ('{$exam_id}','{$class_id}','{$sub_id}','{$stu_id}','{$_POST[$stu_id]}','{$_POST[$stu_roll]}')";
									if(!$db->query($sq))
									{
										$is_success = false;

									}
								}

							}

								if($e_type = "Final-Term")
								{
									
								}

							if($is_success)
							{
								echo "<div class='success'>Insert Success</div>";


							}
							else
							{
								echo "<div class='error'>Insert Failed</div>";
							}


						}



					?>

					<form method="post" action="<?php echo $_SERVER["REQUEST_URI"];?>">

							<?php
								$sl1="select * from result where CID = '{$class_id}' and EID = '{$exam_id}'";
								$r1=$db->query($sl1);
								if($r1->num_rows>0)
								{

									echo "Result already published.......";
								}
								else{
									$sl="select * from student where CID = '{$class_id}'";
									$r=$db->query($sl);
									if($r->num_rows>0)
									{
										echo '
											<table border="1px">
											<tr>
												<th>S.No</th>
												<th>Roll NO</th>
												<th>Name</th>
												<th>CLASS</th>
												<th>Section</th>
												<th>Subject</th>
												<th>Mark</th>
												<th>Remark</th>

											</tr>


										';
										while($row1=$r->fetch_assoc())
	                  {
	                          $stu_id = $row1["ID"];
														$stu_roll = $row1["RNO"];
	        									$stu_name = $row1["NAME"];
	                          $sql2="select * from sub where SID='{$_GET["sub_id"]}'";
	          								$re2=$db->query($sql2);

	        								$sql="select * from class where CID='{$_GET["cl_id"]}'";
	        								$re=$db->query($sql);

	                        if($r1=$re->fetch_assoc())
	                        {

	                            if($r2=$re2->fetch_assoc())
	                            {
	                              echo "
	                              <tr>
	                                <td>{$stu_id}.</td>
																	<td>{$stu_roll}</td>
																	<td>{$stu_name}</td>
	                                <td>{$r1["CNAME"]}</td>
	                                <td>{$r1["CSEC"]}</td>
	                                <td>{$r2["SNAME"]}</td>

																	<td><input type=\"text\" name=\"{$stu_id}\" required class=\"input\"></td>
																	<td><input type=\"text\" name=\"{$stu_roll}\" required class=\"input\" value=\"None\"></td>



	                              </tr>
	                              ";
	                            }




	                        }


	                      }

	        								echo "</table>";
													echo "<button type=\"submit\" style=\"float:right;\" class=\"btn\" name=\"submit\"> Add Mark Details</button>";

									}
									else{
										echo "No students.......";
									}
								}

							 ?>


					</form>
						</div>

				</div>

			</div>

				<?php include"footer.php";?>
	</body>
</html>
