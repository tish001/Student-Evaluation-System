<?php
	include"database.php";
	//session_start();
	
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
		<div>
					<br><h1>View Attendence Details</h1><br>
</div>
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					
					<div class="lbox1">	
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT (SCLASS),SSEC  FROM  student natural JOIN attendance;";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
				<div class="lbox1">	
						<label>SECTION</label><br>
					<select name="sec" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT SSEC  FROM  student natural JOIN attendance;";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SSEC"]}'>{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					<div>
					
				<button type="submit" class="btn" name="view"> View</button>	
						<div>
				<div class="rbox">
					<label>DATE</label><br>
						<select name="date" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(date) FROM attendance";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["date"]}'>{$r["date"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				</div>
								</div>
				
				</form>
					<br>
					<div class="Output">
						<?php
							if(isset($_POST["view"]))
							{
								echo "<h3>Student Attendence Sheet</h3><br>";
								$sql="select ID,NAME,MAIL,P_A,date from attendance natural join student where SCLASS ='{$_POST["cla"]}'and SSEC='{$_POST["sec"]}' and date='{$_POST["date"]}'";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
									echo '
										<table border="1px">
										<tr>
											<th>ID</th>
											<th>NAME</th>
											<th>EMAIL ID</th>
											<th>ATTENDENCE STATUS</th>
											
                                            <th>DATE</th>
                                            <th>UPDATED STATUS</th>
										</tr>
									
									
									';
                                    $i=0;
            while($row = $re->fetch_array()){
			
                ?>
                 <form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                <tr>
               
						<td><?php echo($row['ID']);?></td>
						
                        <input type="hidden" value="<?php echo $row['ID']; ?>" name="ID[]" >
            
                        <td><?php echo $row['NAME'];?></td>
                        
                        <td><?php echo $row['MAIL'];?></td>
                        
                        <td><?php echo $row['P_A']; ?></td>
                        
                        <td><?php echo $row['date']; ?></td>
                        <input type="hidden" value="<?php echo $row['date']; ?>" name="date[]" >
                        <td> <input type="radio" name="attendance_status[<?php echo $i; ?>]" value="present">P
                                <input type="radio" name="attendance_status[<?php echo $i; ?>]" value="absent">A</td>
               
						
                               
                </tr>

            <?php $i++;
            }
		}
		else
							{
								echo "No record Found";
							}
								echo "</table>";
							}
	
					


	

        ?>
                       <input type="submit" name="submit" class="btn btn-primary " value="UPDATE" >    
					   <?php
					   if (isset($_POST['submit'])) {
						foreach ($_POST['attendance_status'] as $id => $attendance_status) {
						  $sql1 = "UPDATE attendance SET P_A='".$_POST['attendance_status'][$id]."' WHERE ID='".$_POST['ID'][$id]."'";
						  $conn = mysqli_connect('localhost','root','','school');
						 
                           if(mysqli_query($conn, $sql1)){
                               echo nl2br ("Records updated successfully for ID".$_POST['ID'][$id]." \n");
                           } 
                           else{
                            echo "Record could not be updated";
                        }
						 }
						}
					  
                     /*  if(isset($_POST['submit']))
                       {
                          
  
                         foreach($_POST['attendance_status'] as $id => $attendance_status){   
                            $ID= $_POST['ID'][$id];
                            $date=$_POST['date'][$id];
                            echo "$ID";
                            echo "$attendance_status";
                            $sql1= "UPDATE  attendance SET P_A='$attendance_status' WHERE ID='$ID' and DATE = '$date'";
						 }
                           
						   $conn = mysqli_connect('localhost','root','','evaluation');
						 
                           if(mysqli_query($conn, $sql1)){
                               echo "Records updated successfully.";
                           } 
                           else{
                            echo "Record could not be updated";
                        }
                       
					} */
					   
					   
                       ?>         
									
					</div>
		
				</div>
				
			</div>
				
	</body>
</html>





