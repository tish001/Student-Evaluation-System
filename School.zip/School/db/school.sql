-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2019 at 07:30 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AID` int(11) NOT NULL,
  `ANAME` varchar(150) NOT NULL,
  `APASS` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AID`, `ANAME`, `APASS`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `CID` int(11) NOT NULL,
  `CNAME` varchar(150) NOT NULL,
  `CSEC` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`CID`, `CNAME`, `CSEC`) VALUES
(7, 'I', 'A'),
(8, 'I', 'B'),
(9, 'I', 'C'),
(10, 'II', 'A'),
(11, 'II', 'B'),
(12, 'II', 'C'),
(13, 'III', 'A'),
(14, 'III', 'B'),
(15, 'IV', 'A'),
(16, 'IV', 'B'),
(18, 'IV', 'C'),
(19, 'V', 'A'),
(20, 'V', 'B'),
(21, 'V', 'C');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `EID` int(11) NOT NULL,
  `ENAME` varchar(150) NOT NULL,
  `ETYPE` varchar(150) NOT NULL,
  `EDATE` varchar(150) NOT NULL,
  `Year` int(11) NOT NULL,
  `CLASS` varchar(255) NOT NULL,
  `Sub_ID` int(11) NOT NULL,
  `Tot_Marks` int(11) NOT NULL,
  `Percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`EID`, `ENAME`, `ETYPE`, `EDATE`, `Year`, `CLASS`, `Sub_ID`, `Tot_Marks`, `Percentage`) VALUES
(27, 'Term', 'I-Term', '15-04-2019', 2019, 'I', 9, 100, 25),
(28, 'term', 'I-Term', '16-04-2019', 2019, 'I', 2, 100, 25),
(29, 'term', 'II-Term', '19-08-2019', 2019, 'I', 9, 100, 25),
(31, 'term', 'II-Term', '20-08-2019', 2019, 'I', 2, 100, 25),
(32, 'final', 'Final-Term', '19-11-2019', 2019, 'I', 9, 100, 50),
(33, 'final', 'Final-Term', '20-11-2019', 2019, 'I', 2, 100, 50);

-- --------------------------------------------------------

--
-- Table structure for table `hclass`
--

CREATE TABLE `hclass` (
  `HID` int(11) NOT NULL,
  `TID` int(11) NOT NULL,
  `CLA` varchar(150) NOT NULL,
  `SEC` varchar(150) NOT NULL,
  `SUB` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `publish`
--

CREATE TABLE `publish` (
  `Pu_ID` int(11) NOT NULL,
  `EID` int(11) NOT NULL,
  `CID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `RID` int(11) NOT NULL,
  `EID` int(11) NOT NULL,
  `CID` int(11) NOT NULL,
  `SID` int(11) NOT NULL,
  `STU_ID` int(11) NOT NULL,
  `MARKS` float NOT NULL,
  `EVAL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`RID`, `EID`, `CID`, `SID`, `STU_ID`, `MARKS`, `EVAL`) VALUES
(17, 27, 7, 9, 16, 50, 'Below average.Please take proper care'),
(18, 27, 7, 9, 17, 60, 'None'),
(19, 27, 7, 9, 18, 80, 'None'),
(20, 27, 8, 9, 19, 80, 'None'),
(21, 27, 8, 9, 20, 85, 'None'),
(22, 27, 9, 9, 21, 78, 'None'),
(23, 28, 7, 2, 16, 75, 'None'),
(24, 28, 7, 2, 17, 80, 'None'),
(25, 28, 7, 2, 18, 90, 'None'),
(26, 28, 8, 2, 19, 80, 'None'),
(27, 28, 8, 2, 20, 95, 'None'),
(28, 29, 7, 9, 16, 82, 'None'),
(29, 29, 7, 9, 17, 60, 'None'),
(40, 32, 7, 9, 16, 82, 'None'),
(41, 32, 7, 9, 17, 60, 'None'),
(42, 32, 7, 9, 18, 80, 'None'),
(43, 32, 8, 9, 19, 80, 'None'),
(44, 32, 8, 9, 20, 70, 'None');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `TID` int(11) NOT NULL,
  `TNAME` varchar(150) NOT NULL,
  `TPASS` varchar(150) NOT NULL,
  `QUAL` varchar(150) NOT NULL,
  `SAL` varchar(150) NOT NULL,
  `PNO` varchar(150) NOT NULL,
  `MAIL` varchar(150) NOT NULL,
  `PADDR` text NOT NULL,
  `IMG` varchar(150) NOT NULL,
  `SUB` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`TID`, `TNAME`, `TPASS`, `QUAL`, `SAL`, `PNO`, `MAIL`, `PADDR`, `IMG`, `SUB`) VALUES
(16, 'Sanjida Reza', '1234', 'Msc', '50000', '0175757575', 'sanjida@gmail.com', '535446464', 'staff/teacher.jpg', 'Science'),
(17, 'Rezaul karim', '1234', 'Msc', '50000', '01757454545454', 'ramis@gmail.com', '24 south mughpara', 'staff/teacher.jpg', 'Social Science'),
(18, 'Mohit Chowdhury', '1234', 'Msc', '50000', '0178787657867', 'mohit@gmail.com', '24 north mughpara', 'staff/teacher.jpg', 'English'),
(19, 'Amol Deb', '1234', 'Msc', '50000', '0178787657867', 'amol@gmaiil.com', '24 south moghbazar', 'staff/teacher.jpg', 'Maths'),
(20, 'Parvina Akhter', '1234', 'Msc', '50000', '0178787657867', 'parvin@gmail.com', '173 Aftab nagar', 'staff/teacher.jpg', 'Bangla'),
(21, 'Hafiqur Rahman', '1234', 'Msc', '50000', '0178787657867', 'hafiz@gmail.com', '173 Peyarabagh', 'staff/teacher.jpg', 'Religion');INSERT INTO `staff` (`TID`, `TNAME`, `TPASS`, `QUAL`, `SAL`, `PNO`, `MAIL`, `PADDR`, `IMG`, `SUB`) VALUES
(16, 'Sanjida Reza', '1234', 'Msc', '50000', '0175757575', 'sanjida@gmail.com', '535446464', 'staff/teacher.jpg', 'Science'),
(17, 'Rezaul karim', '1234', 'Msc', '50000', '01757454545454', 'ramis@gmail.com', '24 south mughpara', 'staff/teacher.jpg', 'Social Science'),
(18, 'Mohit Chowdhury', '1234', 'Msc', '50000', '0178787657867', 'mohit@gmail.com', '24 north mughpara', 'staff/teacher.jpg', 'English'),
(19, 'Amol Deb', '1234', 'Msc', '50000', '0178787657867', 'amol@gmaiil.com', '24 south moghbazar', 'staff/teacher.jpg', 'Maths'),
(20, 'Parvina Akhter', '1234', 'Msc', '50000', '0178787657867', 'parvin@gmail.com', '173 Aftab nagar', 'staff/teacher.jpg', 'Bangla'),
(21, 'Hafiqur Rahman', '1234', 'Msc', '50000', '0178787657867', 'hafiz@gmail.com', '173 Peyarabagh', 'staff/teacher.jpg', 'Religion');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `RNO` varchar(255) NOT NULL,
  `NAME` varchar(150) NOT NULL,
  `FNAME` varchar(150) NOT NULL,
  `DOB` varchar(150) NOT NULL,
  `GEN` varchar(150) NOT NULL,
  `PHO` varchar(150) NOT NULL,
  `MAIL` varchar(150) NOT NULL,
  `ADDR` text NOT NULL,
  `SIMG` varchar(150) NOT NULL,
  `AID` int(11) NOT NULL,
  `PASS` varchar(255) NOT NULL DEFAULT '1234',
  `CID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `RNO`, `NAME`, `FNAME`, `DOB`, `GEN`, `PHO`, `MAIL`, `ADDR`, `SIMG`, `AID`, `PASS`, `CID`) VALUES
(16, 'S101', 'Samin Rahman', 'test1', '14-10-2014', 'Male', '0175729556', 'something@gmail.com', 'dasdadafsfsgsgsfsff', 'student/images.jpg', 1, '1234', 7),
(17, 'S102', 'Arafat Yousuf', 'asdasadada', '15-09-2014', 'Male', '0175729556', 'something@gmail.com', 'dsaadafsgdgdgd', 'student/images.jpg', 1, '1234', 7),
(18, 'S103', 'Rifah Tasnia', 'fsfsfsfs', '16-10-2014', 'Female', '0175729556', 'something@gmail.com', 'asadadadassasa', 'student/images.jpg', 1, '1234', 7),
(19, 'S104', 'rakib', 'dsfsfsfs', '18-09-2014', 'Male', '0175729556', 'something@gmail.com', 'sdfsfsfdssf', 'student/images.jpg', 1, '1234', 8),
(20, 'S105', 'rakib 2', 'asdadad', '18-06-2014', 'Male', '0175729556', 'something@gmail.com', 'sfsgrtetetetetetet', 'student/images.jpg', 1, '1234', 8),
(21, 'S106', 'simon', 'adasdadadas', '26-08-2014', 'Male', '0175729556', 'something@gmail.com', 'adadadgfgdgdfgddgdf', 'student/images.jpg', 1, '1234', 9);

-- --------------------------------------------------------

--
-- Table structure for table `sub`
--

CREATE TABLE `sub` (
  `SID` int(11) NOT NULL,
  `SNAME` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub`
--

INSERT INTO `sub` (`SID`, `SNAME`) VALUES
(2, 'English'),
(3, 'Maths'),
(5, 'Social Science'),
(8, 'Bangla'),
(9, 'Science'),
(10, 'Religion');

-- --------------------------------------------------------

--
-- Table structure for table `sub_teacher`
--

CREATE TABLE `sub_teacher` (
  `ID` int(11) NOT NULL,
  `Sub_ID` int(11) DEFAULT NULL,
  `TID` int(11) DEFAULT NULL,
  `CID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_teacher`
--

INSERT INTO `sub_teacher` (`ID`, `Sub_ID`, `TID`, `CID`) VALUES
(3, 9, 16, 7),
(4, 9, 16, 8),
(5, 9, 16, 9),
(6, 9, 16, 10),
(7, 9, 16, 11),
(9, 2, 18, 7),
(10, 2, 18, 8),
(11, 2, 18, 9),
(12, 2, 18, 10),
(14, 9, 16, 12),
(15, 2, 18, 11),
(16, 2, 18, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`EID`);

--
-- Indexes for table `hclass`
--
ALTER TABLE `hclass`
  ADD PRIMARY KEY (`HID`);

--
-- Indexes for table `publish`
--
ALTER TABLE `publish`
  ADD PRIMARY KEY (`Pu_ID`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`RID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`TID`),
  ADD UNIQUE KEY `MAIL` (`MAIL`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RNO` (`RNO`);

--
-- Indexes for table `sub`
--
ALTER TABLE `sub`
  ADD PRIMARY KEY (`SID`);

--
-- Indexes for table `sub_teacher`
--
ALTER TABLE `sub_teacher`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `CID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `EID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `hclass`
--
ALTER TABLE `hclass`
  MODIFY `HID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `publish`
--
ALTER TABLE `publish`
  MODIFY `Pu_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `RID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `TID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `sub`
--
ALTER TABLE `sub`
  MODIFY `SID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sub_teacher`
--
ALTER TABLE `sub_teacher`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
