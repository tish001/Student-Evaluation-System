<?php
	include"database.php";
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label>Teacher ID:</label><br>
					<select name="TID" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT TID FROM  teacher order by TID ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["TID"]}'>{$ro["TID"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					<div class="lbox1">	
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT(SCLASS) FROM student order by SCLASS ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>
						
				</div>
				<div class="rbox">
					<label>Section</label><br>
						<select name="sec" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(SSEC) FROM student order by SSEC ASC";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["SSEC"]}'>{$r["SSEC"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				
				</div>
					<button type="submit" class="btn" name="view"> View Details</button>
				
						
					</form>
					<br>
					
					<div class="Output">
							
                   
        
		<?php
							if(isset($_POST["view"]))
							{
                                ?>
                                <center>
							<h3>Attendence Sheet</h3><br>
							<!--div class="lbox1">
							<label>Teacher info: </label>
					<select name="tea" required class="input3"!-->
				
						<?php 
						
							/* $sl="SELECT DISTINCT(TID), TNAME FROM teacher order by TID ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["TID"]}  {$ro["TNAME"]}'>{$ro["TID"]} {$ro["TNAME"]}</option>";
										}
									}*/
						?>
					
					</select>
				<br><br><br>
								   <label>DATE:</label>
								   
								   
                        <center>
                                <?php
                               
								$sql="select * from student where SCLASS='{$_POST["cla"]}' and SSEC='{$_POST["sec"]}'";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
 
									echo '
										<table border="1px">
										<thead>
										<tr>
										
										
											<th>serialno</th>
											<th>ID</th>
											<th>Name</th>
											<th>Attendence</th>
											<th>Late</th>
                                        
											
										</tr>
										<thead>
									
									
									';
            $i=0;
            while($row = $re->fetch_array()){
			
                ?>
                 <form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                 
                <tr>
                <td><?php echo($i)+(1);?></td>
						<td><?php echo($row['ID']);?></td>
						
                <input type="hidden" value="<?php echo $row['ID']; ?>" name="ID[]" >
			
			
                <td><?php echo $row['NAME'];?></td>
                <input type="hidden" value="<?php echo $row['NAME']; ?>" name="NAME[]" >
				<input type="hidden" value="<?php echo $row['TID']; ?>"name="TID[]" id="TID[]"></td>
				 <input type="hidden" value="<?php echo $row['SSEC']; ?>"name="SSEC[]" id="SSEC[]"></td>
				 <input type="hidden" value="<?php echo $row['SCLASS']; ?>"name="SCLASS[]" id="SCLASS[]"></td>    
						    
           <td> <input type="radio" name="attendance_status[<?php echo $i; ?>]" value="present">P
			<input type="radio" name="attendance_status[<?php echo $i; ?>]" value="absent">A</td>
			<td><input type="radio" name="late[<?php echo $i; ?>]" value="yes">yes
			<input type="radio" name="late[<?php echo $i; ?>]" value="no"checked="checked">no</td>
                </tr>

            <?php $i++;
            }
		   ?>
		  
          <input type="text" name="date" placeholder="like:2019-12-02" id="date"><br><br>
          
		
								</div>
           <?php
		}
		else
							{
								echo "No record Found";
							}
								echo "</table>";
							}
	
					


	

        ?>
<input type="submit" name="submit" class="btn btn-primary " value="submit" >

<?php
if(isset($_POST['submit']))
{
   if(!empty($_POST['attendance_status'])){
  foreach($_POST['attendance_status'] as $id => $attendance_status) {
	?>
	
    
    <?php
        $ID= $_POST['ID'][$id];
        $NAME= $_POST['NAME'][$id];
		$late=$_POST['late'][$id];
		$date=$_POST['date'];
		$TID=$_POST['TID'][$id];
		$SCLASS = $_POST['SCLASS'][$id];
		$SSEC = $_POST['SSEC'][$id];
		
     $sql1= "INSERT INTO attendance(ID, TID, NAME, P_A, Late, date, SCLASS, SSEC) VALUES ('$ID','$TID', '$NAME','$attendance_status','$late','$date', '$SCLASS', '$SSEC') order by ID  ASC";

    $conn = mysqli_connect('localhost','root','','school');
    if(mysqli_query($conn, $sql1)){
		echo nl2br ("Records updated successfully for ID".$_POST['ID'][$id]." \n");
    } else{
		
        echo nl2br("\n Attendance already been taken for  '$NAME! for the $date") ;
    }
}
  }  else{
        echo '<i  style="color:red;font-size:25px ;">
		Attendence is missing! Please recheck!!! </i>';
    }
}

    ?>
                        </form>
        

    </table>
									
</html>

