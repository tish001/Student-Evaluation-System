<?php
$connect = mysqli_connect("localhost", "root", "", "evaluation");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM attendance 
	WHERE ID LIKE '%".$search."%'
	OR NAME LIKE '%".$search."%' 
	OR P_A LIKE '%".$search."%' 
	OR date LIKE '%".$search."%'
	";
}
else
{
	$query = "
	select * from attendance ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
						<th>ID</th>		
						<th>NAME</th>
						<th>ATTENDENCE STATUS</th>
						<th>DATE</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["ID"].'</td>
				<td>'.$row["NAME"].'</td>
				<td>'.$row["P_A"].'</td>
				<td>'.$row["date"].'</td>
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>