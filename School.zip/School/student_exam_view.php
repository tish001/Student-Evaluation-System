<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["SID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";

	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Tutor Joe's</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
			<?php include"navbar.php";?><br>

			<img src="img/1.jpg" style="margin-left:90px;" class="sha">

			<div id="section">

					<?php include"sidebar.php";?><br><br><br>

					<h3 class="text">Welcome <?php echo $_SESSION["SNAME"]; ?></h3><br><hr><br>

				<div class="content">

						<h3 >View Exam Time Table Details</h3><br>



						<table border="1px">
							<tr>
								<th>S.No</th>
								<th>Class </th>
								<th>Subject</th>
								<th>Exam Name</th>
								<th>Term</th>
								<th>Date</th>

							</tr>
							<?php
								$s="select * from class where CID = '{$_SESSION["S_CID"]}'";
								$res=$db->query($s);
								if($res->num_rows>0)
								{
                  $cl=$res->fetch_assoc();
                  $class = $cl["CNAME"];

                  $s="select * from exam where CLASS = '{$class}'  order by EDATE";
  								$res=$db->query($s);
  								if($res->num_rows>0)
  								{
                    $i=0;
                    while($r=$res->fetch_assoc())
  									{
  										$i++;
  										$s1="select * from sub where SID = '{$r["Sub_ID"]}'";
  										$re2=$db->query($s1);
  										if($re2->num_rows>0)
  										{
  											$sub=$re2->fetch_assoc();
  										echo "
  											<tr>
  												<td>{$i}</td>
  												<td>{$class}</td>
  												<td>{$sub["SNAME"]}</td>
  												<td>{$r["ENAME"]}</td>
  												<td>{$r["ETYPE"]}</td>
  												<td>{$r["EDATE"]}</td>


  											</tr>



  										";
  									}

  									}
                  }

								}
								else
								{
									echo "No Record Found";
								}



							?>









						</table>

				</div>


			</div>

				<?php include"footer.php";?>
	</body>
</html>
