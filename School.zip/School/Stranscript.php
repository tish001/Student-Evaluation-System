<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["ID"]))
	{
		echo"<script>window.open('student_login.php?mes=Access Denied...','_self');</script>";

	}


	$sql="SELECT * FROM mark WHERE ID={$_SESSION["ID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{

			$row1=$res->fetch_assoc();

		}
	
?>

<!DOCTYPE html>
<html>
	<head>
        <link rel="stylesheet" href="css/styledetail.css">
        
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label>STUDENT ID:</label><br>
					<select name="SID" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT ID FROM  student order by ID ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["ID"]}'>{$ro["ID"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					
					
					<button type="submit" class="btn" name="view"> View Details</button>
				
						
					</form>
                    <br><br><br>
                    <div class="Output">
							
                   
        
                            <?php
                                                if(isset($_POST["view"]))
                                                {
                                                    ?>
                                                    <center>
                                                <h2>STUDENT TRANSCRIPT</h2><br>
                                                
                                                <center>
								<?php
							
                               
								$sql="select ID,NAME,TSUB,SCLASS,SSEC,grade from mark natural join student where 
                                ID='{$_POST["SID"]}'";
                                $avg=0;
                                

								$re=$db->query($sql);
								if($re->num_rows>0)
								{
                                   
                                    echo '
                                
										<table border="2px">
										<thead>
										<tr>
											
                                            <th>SUBJECT</th>
                                            <th>GRADE</th>
										</tr>
										<thead>
									
									
                                    ';
                                    $i=0;
                                    $tgpa = 0;
                                    $j=0;
									while($r=$re->fetch_assoc())
									{
                                        $j++;

                                        $i++;
										echo "
										<tr>
											
											
											<td>{$r["TSUB"]}</td>
											<td>{$r["grade"]}</td>
											
</tr>
                                        ";
                                        $gpa=0;
                                        if($r["grade"]=="A"||$r["grade"]=="A+")
                                        {
                                            $gpa=5;
                                            $tgpa+=$gpa;
                                        }
                                        elseif($r["grade"]=="B"||$r["grade"]=="C")
                                        {
                                            $gpa=3.5;
                                            $tgpa+=$gpa;
                                        }
                                        elseif($r["grade"]=="D")
                                        {
                                            $gpa=2;
                                            $tgpa+=$gpa;
                                        }
                                        else{
                                            $gpa=0;
                                            $tgpa+=$gpa;
                                        }

                                        
									
										
										$i++;
                                    
                                    }
                                    //echo "$j";
                                    $avg=$tgpa/($j);
								}
							else
							{
							
								echo "No record found";
								
								
                            }
                            
								
							}
						
						
						?>
						
					
						</center>
						</table>
                        <?php
                        if($avg>=3.5){
                                echo "Your gpa is $avg\n";
                                echo "<h3>Your result is good!</h3>";
                            }
                            elseif($avg>=2){
                                echo "Your gpa is $avg";
                                echo "<h3> Your result is satisfactory!</h3>";
                            }
                            else{
                                echo "Your gpa is $avg";
                                echo "Your result is poor!";
                            }
                        ?>
					
	</body>
</html>





