<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";

	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>

	<body>
			<?php include"navbar.php";?><br>
			<img src="img/1.jpg" style="margin-left:90px;" class="sha">

			<div id="section">

				<?php include"sidebar.php";?><br><br><br>

				<h3 class="text">Welcome <?php echo $_SESSION["ANAME"]; ?></h3><br><hr><br>
				<div class="content">

						<h3 > Add Teacher Details</h3><br>

					
					<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>">
							<div class = "lbox">

							<label>TeacherID</label><br>
							     <input type="text" name="TID" required class="input">
							     <br><br>
									 <label>Teacher Name</label><br>
							     <input type="text" name="TNAME" required class="input">
							     <br><br>
							     
									
									 <label>Mail</label><br>
							     <input type="text" name="TMAIL" required class="input">
							     <br><br>
									

								
												
											 <label>Password</label><br>
									     <input type="text" name="TPASS" required class="input">
									     <br><br>
											 <label>Subject</label><br>
						 					<input type="text" name="TSUB" required class="input">
						 					<br><br>
									
									    <button type="submit" class="btn" name="submit">Add Teacher Details</button>
										<?php
						if(isset($_POST["submit"]))
						{

							$target="teacher/";
						 
						// if(move_uploaded_file($_FILES['image']['tmp_name'],$target_file))
						 	//{
									$sq="insert into teacher(TID,TSUB,TNAME,TMAIL,TPASS) values('{$_POST["TID"]}','{$_POST["TSUB"]}','{$_POST["TNAME"]}','{$_POST["TMAIL"]}','{$_POST["TPASS"]}')";
									if($db->query($sq))
									{
										echo "<div class='success'>Insert Success..</div>";
									}
									else
									{
										echo "<div class='error'>Insert Failed..</div>";
									}

								//}

						}

					?>

							</div>
					</form>


				</div>


			</div>

				<?php include"footer.php";?>
	</body>
</html>
