<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";

	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
			<?php include"navbar.php";?><br>
			<img src="img/1.jpg" style="margin-left:90px;" class="sha">

			<div id="section">

					<?php include"sidebar.php";?><br><br><br>

					<h3 class="text">Welcome <?php echo $_SESSION["ANAME"]; ?></h3><br><hr><br>

				<div class="content">
				
				<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
						<h3 >Assign Teacher to a Class Details</h3><br>
						<?php
						if(isset($_POST["submit"]))
						{
							 $sq="insert into class(SCLASS,SSEC, TID, TSUB) values('{$_POST["cla"]}','{$_POST["sec"]}', '{$_POST["TID"]}', '{$_POST["sub"]}')";
							if($db->query($sq))
							{
								echo "<div class='success'>Insert Success..</div>";
							}
							else
							{
								echo "<div class='error'>Insert failed..</div>";
							}


						}

					?>
						<label>Class Name</label><br>
				<select name="cla"  required class="input2">
						<option value="">Select</option>
						<option value="I">I</option>
						<option value="II">II</option>
						<option value="III">III</option>
						<option value="IV">IV</option>
						<option value="V">V</option>
						<option value="VI">VI</option>
						<option value="VII">VII</option>
						<option value="VIII">VIII</option>
						<option value="IX">IX</option>
						<option value="X">X</option>

					</select><br><br>
					<label>Section </label><br>
					<select name="sec"  required class="input2">
						<option value="">Select</option>
						<option value="-">-</option>
						<option value="A">A</option>
						<option value="B">B</option>
						<option value="C">C</option>
					</select>


					

			
				<div class="rbox">
				<br><br>
          <label>Teacher</label><br>
					<select name="TID" required class="input3">
						<?php
							$s="select * from teacher";
							$re=$db->query($s);
							if($re->num_rows>0)
							{
								echo "<option value=''>select</option>";
								while($r=$re->fetch_assoc())
								{

                  echo "<option value='{$r["TID"]}'>{$r["TID"]}{$r["TNAME"]}{$r["TSUB"]}</option>";
								}
							}
						?>
			
					</select>
					<label> Subject</label>
					<select name="sub"  required class="input2">
						<option value="">Select</option>
						<option value="-">-</option>
						<option value="Bangla">Bangla</option>
						<option value="English">English</option>
						<option value="Math">Math</option>
						<option value="Science">Science</option>
						<option value="Sociology">Sociology</option>

					</select>
					<br>

					<br><br>
					


				</div>
					<br><br>
					<button type="submit" class="btn" name="submit">Add</button>
				</form>


				</div>


			</div>

				
</html>
