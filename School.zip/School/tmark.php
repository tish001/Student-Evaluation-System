<?php
	include"database.php";
	
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label>Teacher ID:</label><br>
					<select name="TID" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT TID FROM  teacher order by TID ASC";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["TID"]}'>{$ro["TID"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					
					<div class="lbox1">	
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT(SCLASS) FROM attendance  ";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]}</option>";
										}
									}
						?>
					
					</select>
					<br><br>
						
				</div>
				<div class="rbox">
					<label>Section</label><br>
						<select name="sec" required class="input3">
				
						<?php 
							 $sql="SELECT DISTINCT(SSEC) FROM attendance order by SSEC ASC";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["SSEC"]}'>{$r["SSEC"]}</option>";
										}
									}
						?>
					
					</select><br><br>
				
				</div>
					<button type="submit" class="btn" name="view"> View Details</button>
				
						
					</form>
                    <div class="Output">
							
                   
        
                            <?php
                                                if(isset($_POST["view"]))
                                                {
                                                    ?>
                                                    <center>
                                                <h2>MARK SHEET</h2><br>
                                                
                                                <center>
								<?php
							
                               
								$sql="select ID,NAME,TNAME,SCLASS,SSEC,TSUB,grade from mark natural join teacher where SCLASS='{$_POST["cla"]}' and SSEC='{$_POST["sec"]}' and
                                TID='{$_POST["TID"]}'group by ID";

								$re=$db->query($sql);
								if($re->num_rows>0)
								{
                                   
                                    echo '
                                
										<table border="2px">
										<thead>
										<tr>
											<th>ID</th>
											<th>Name</th>
                                            <th>Grade</th>
                                            <th>Remark</th>
										</tr>
										<thead>
									
									
                                    ';
                                    $i=0;
                                    
									while($r=$re->fetch_assoc())
									{
                                        if($i==0)
                                        {
                                           
                                            echo" TEACHER NAME: {$r["TNAME"]} 
                                            CLASS: {$r["SCLASS"]}
                                            SECTION: {$r["SSEC"]}
                                            SUBJECT: {$r["TSUB"]}
                                                                            ";
                                                   $i++;
                                        }
									else{
                                        if($r["grade"]=="A"||$r["grade"]=="A+")
                                        {
                                            $remark="GOOD!";
                                        }
                                        elseif($r["grade"]=="B"||$r["grade"]=="C")
                                        {
                                            $remark="AVERAGE!";
                                        }
                                        elseif($r["grade"]=="D")
                                        {
                                            $remark="BELOW AVERAGE!";
                                        }
                                        else{
                                            $remark="POOR!";
                                        }


                                        echo "
                                        
										<tr>
											
											<td>{$r["ID"]}</td>
											<td>{$r["NAME"]}</td>
                                            <td>{$r["grade"]}</td>
                                            <td>{$remark}</td>
                                            
                                
						
</tr>
										";
									
										
                                        $i++;
                                    }
									}
								}
							else
							{
							
								echo "No record found";
								
								
							}
								
							}
						
						
						?>
						
					
						</center>
						</table>
					
	</body>
</html>


                                    