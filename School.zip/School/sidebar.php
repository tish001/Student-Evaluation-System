<div class="sidebar"><br>
		<h3 class="text">Dashboard</h3><br><hr><br>
		<ul class="s">
		<?php
			if(isset($_SESSION["AID"]))
			{
				echo'
					<li class="li"><a href="admin_home.php">School Information</a></li>
					<li class="li"><a href="add_staff.php"> Add Teacher</a></li>
					<li class="li"><a href="assign_teacher.php"> Assign Class to teacher</a></li>
					<li class="li"><a href="view_staff.php">View Teacher</a></li>
					<li class="li"><a href="student.php"target="_blank"> View Student</a></li>
					<li class="li"><a href="add_stud.php"target="_blank"> Add Student</a></li>
					<li class="li"><a href="logout.php">Logout</a></li>

				';


			}
			elseif(isset($_SESSION["TID"])){
				echo'
					<li class="li"><a href="teacher_home.php">Profile</a></li>

					<li class="li"><a href="teacher_class.php"> Classes</a></li>
					<li class="li"><a href="view_stud_teach.php" target="_blank"> View Student</a></li>
					
					<li class="li"><a href="add_mark.php">Add Marks</a></li>
					<li class="li"><a href="view_mark.php">View Marksheet</a></li>
					<li class="li"><a href="#">Add Attendance </a></li>
					<li class="li"><a href="logout.php">Logout</a></li>


				';
			}
			else {
				echo'
					<li class="li"><a href="student_home.php">Profile</a></li>
					<li class="li"><a href="student_exam_view.php">View Exam</a></li>
					<li class="li"><a href="#">View Attendance Details</a></li>
					<li class="li"><a href="student_view_result.php">View Term Marks</a></li>
					<li class="li"><a href="#">View Final Result</a></li>

					
					<li class="li"><a href="logout.php">Logout</a></li>


				';
			}


		?>


		</ul>

</div>
