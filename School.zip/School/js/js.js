$("#submitAttendance").click(function(){
    alert('clicked');
});