<?php
	include"database.php";
	session_start();
	
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/styledetail.css">
		<div>
					<br><h1>View MARK SHEET</h1><br>
</div>
	</head>
	<body>
		
				
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">	
						<label>Teacher ID:</label><br>
					<select name="TID" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT TID FROM  mark natural join teacher";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["TID"]}'>{$ro["TID"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					<div class="lbox1">	
						<label>Class</label><br>
					<select name="cla" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT (SCLASS),SSEC  FROM  student natural JOIN mark";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SCLASS"]}'>{$ro["SCLASS"]} </option>";
											
											//echo "<option value='{$ro["SCLASS"]}''{$ro["SSEC"]}'>{$ro["SCLASS"]}{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
				<div class="lbox1">	
						<label>SECTION</label><br>
					<select name="sec" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT SSEC  FROM  student natural JOIN mark;";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["SSEC"]}'>{$ro["SSEC"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
				<div class="lbox1">	
						<label>YEAR</label><br>
					<select name="year" required class="input3">
				
						<?php 
						
							 $sl="SELECT DISTINCT year  FROM  mark ";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["year"]}'>{$ro["year"]}</option>";
											
										}
									}
						?>
					
					</select>
					<br><br>	
				</div>
					
				<button type="submit" class="btn" name="view"> View</button>	
				</div>
								</div>
				
				</form>
					<br>
					<div class="Output">
						<?php
							if(isset($_POST["view"]))
							{
								echo "<h3>Student Mark Sheet</h3><br>";
								$sql="select ID,NAME,MID1,MID2,FINAL,quiz1,quiz2,quiz3,classwork,year,TID,TSUB  from mark natural join student  where 
								SCLASS ='{$_POST["cla"]}'and SSEC='{$_POST["sec"]}' and year='{$_POST["year"]}' and TID='{$_POST["TID"]}'";
								$re=$db->query($sql);
								if($re->num_rows>0)
								{
									echo '
										<table border="1px">
										<tr>
										<table border="1px">
										<thead>
										<tr>
										
										
										
											<th>ID</th>
											<th>Name</th>
											<th>MID1</th>
											<th>QUIZ1</th>
											<th>MID2</th>
											<th>QUIZ2</th>
											<th>FINAL</th>
											<th>QUIZ3</th>
											<th>CLASSWORK</th>
											
										</tr>
										<thead>
									
									
									
									
									';
                                    $i=0;
            while($row = $re->fetch_array()){
			
                ?>
                 <form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
                <tr>
               
						<td><?php echo($row['ID']);?></td>
						
                        <input type="hidden" value="<?php echo $row['ID']; ?>" name="ID[]" >
            
                        <td><?php echo $row['NAME'];?></td>
                        <input type="hidden" value="<?php echo $row['NAME']; ?>" name="NAME[]" size="10" color: blue>
                        <td><input type="text" value="<?php echo ((float)$row['MID1'])*40.0/25.0; ?>" name="MID1[]"size="10" color: blue ></td>
						<td><input type="text" value="<?php echo ((float)$row['quiz1'])*10.0/5.0; ?>" name="q1[]" size="10" color: blue></td>
                        <td><input type="text" value="<?php echo ((float)$row['MID2'])*40.0/25.0;?>" name="MID2[]" ></td>
						<td><input type="text" value="<?php echo ((float)$row['quiz2'])*10.0/5.0; ?>" name="q2[]" size="10" color: blue></td>
						<td><input type="text" value="<?php echo ((float)$row['FINAL'])*40.0/25.0; ?>" name="FINAL[]" ></td>
						<td><input type="text" value="<?php echo ((float)$row['quiz3'])*10.0/5.0; ?>" name="q3[]" size="10" color: blue></td>
						<td><input type="text" value="<?php echo ((float)$row['classwork']); ?>" name="clw[]" size="10" color: blue></td>
						<input type="hidden" value="<?php echo $row['year']; ?>" name="year[]" >
						
                               
                </tr>

            <?php $i++;
            }
		}
		else
							{
								echo "No record Found";
							}
								echo "</table>";
							}
	

        ?>
                       <input type="submit" name="submit" class="btn btn-primary " value="UPDATE" >    
					   <?php
					   if (isset($_POST['submit'])) {
						foreach ($_POST['ID'] as $id =>$ID) {
						  $sql1 = "UPDATE mark SET MID1='".((float)$_POST['MID1'][$id])*25.0/40.0."', MID2='".((float)$_POST['MID2'][$id])*25.0/40.0."',FINAL='".((float)$_POST['FINAL'][$id])*25.0/40.0."',quiz1 ='".((float)$_POST['q1'][$id])*5.0/10.0."', quiz2 ='".((float)$_POST['q2'][$id])*5.0/10.0."',
						   quiz3 ='".((float)$_POST['q3'][$id])*5.0/10.0."',classwork ='".$_POST['clw'][$id]."' WHERE ID='".$_POST['ID'][$id]."' ";
						  $conn = mysqli_connect('localhost','root','','evaluation');
						 
                           if(mysqli_query($conn, $sql1)){
                               echo nl2br ("Records updated successfully for ID".$_POST['ID'][$id]." \n");
                           } 
                           else{
                            echo "Record could not be updated";
                        }
						 }
						}
					  
                     /*  if(isset($_POST['submit']))
                       {
                          
  
                         foreach($_POST['attendance_status'] as $id => $attendance_status){   
                            $ID= $_POST['ID'][$id];
                            $date=$_POST['date'][$id];
                            echo "$ID";
                            echo "$attendance_status";
                            $sql1= "UPDATE  attendance SET P_A='$attendance_status' WHERE ID='$ID' and DATE = '$date'";
						 }
                           
						   $conn = mysqli_connect('localhost','root','','evaluation');
						 
                           if(mysqli_query($conn, $sql1)){
                               echo "Records updated successfully.";
                           } 
                           else{
                            echo "Record could not be updated";
                        }
                       
					} */
					   
					   
                       ?>         
									
					</div>
		
				</div>
				
			</div>
				
	</body>
</html>





