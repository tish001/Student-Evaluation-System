<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";

	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>

	<body>
			<?php include"navbar.php";?><br>
			<img src="img/1.jpg" style="margin-left:90px;" class="sha">

				<div id="section">
					<?php include"sidebar.php";?><br><br><br>

					<h3 class="text">Welcome <?php echo $_SESSION["ANAME"]; ?></h3><br><hr><br>

					<div class="content1">

						<h3 > View Staff Details</h3><br>
						<?php
								$sql="SELECT * FROM teacher ";
								$res=$db->query($sql);
									echo "<table border='1px' class='table'>
											<tr>
												<th>S.No</th>
												<th>Name</th>
								
												<th>Subject</th>
												<th>Mail</th>
											</tr>
											";
								if($res->num_rows>0)

								{
									$i=0;
									while($row=$res->fetch_assoc())
									{
										$i++;
										echo "<tr>
											<td>{$i}</td>
											<td>{$row["TNAME"]}</td>
											<td>{$row["TSUB"]}</td>
											<td>{$row["TMAIL"]}</td>
											</tr>
										";
									}
											echo "</table>";
								}

								else
								{
									echo "<p>No Record Found</p>";
								}
						 ?>
						<br>
						<div id="box"></div>

					</div>
				</div>


			<?php include"footer.php";?>


	</body>
</html>
