<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["ID"]))
	{
		echo"<script>window.open('student_login.php?mes=Access Denied...','_self');</script>";

	}


	$sql="SELECT * FROM student WHERE ID={$_SESSION["ID"]}";
		$res=$db->query($sql);

		if($res->num_rows>0)
		{

			$row1=$res->fetch_assoc();

		}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Student Evaluation System</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include"navbar.php";?><br>

			<div id="section">
				<?php include"sidebartt.php";?><br>
					<h3 class="text">Welcome <?php echo $_SESSION["NAME"]; ?></h3><br><hr><br>
				<div class="content">




					<div class="rbox1">
					<h3> Profile</h3><br>
						<table border="1px">
							<tr><th>Name </th> <td><?php echo $row1["NAME"] ?> </td></tr>
							<tr><th>ID </th> <td><?php echo $row1["ID"] ?>  </td></tr>
							<tr><th>Class </th> <td> <?php echo $row1["SCLASS"] ?>  </td></tr>
							<tr><th>Section </th> <td> <?php echo $row1["SSEC"] ?> </td></tr>
							<tr><th>E - Mail </th> <td> <?php echo $row1["MAIL"] ?> </td></tr>
							<tr><th>Address </th> <td> <?php echo $row1["ADDR"] ?> </td></tr>
						</table>
					</div>
				</div>
			</div>

				<?php include"footer.php";?>
	</body>
</html>
