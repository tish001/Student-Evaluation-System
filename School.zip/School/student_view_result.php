<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["SID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";

	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Tutor Joe's</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<?php include"navbar.php";?><br>
		<img src="img/1.jpg" style="margin-left:90px;" class="sha">	<br><br>
			<div id="section">

				<h3 class="text">Welcome <?php echo $_SESSION["SNAME"]; ?></h3><br><hr><br>
				<div class="content">
				<h3 >View Result</h3><br>
					<form  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
					<div class="lbox1">
						<label>Term</label><br>
					<select name="term_id" required class="input3">

						<?php
							 $sl="SELECT * FROM exam WHERE CLASS = ANY (SELECT  CNAME FROM class WHERE CID = '{$_SESSION["S_CID"]}')";
							$r=$db->query($sl);
								if($r->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($ro=$r->fetch_assoc())
										{
											echo "<option value='{$ro["EID"]}'>{$ro["ETYPE"]}</option>";
										}
									}
						?>

					</select>
					<br><br>

				</div>
				<div class="rbox">
					<label>Section</label><br>
						<select name="sec" required class="input3">

						<?php
							 $sql="SELECT DISTINCT(CSEC) FROM class";
							$re=$db->query($sql);
								if($re->num_rows>0)
									{
										echo"<option value=''>Select</option>";
										while($r=$re->fetch_assoc())
										{
											echo "<option value='{$r["CSEC"]}'>{$r["CSEC"]}</option>";
										}
									}
						?>

					</select><br><br>
				</div>
					<button type="submit" class="btn" name="view"> View Details</button>


					</form>
					<br>
					<div class="Output">
						<?php
							if(isset($_POST["view"]))
							{
								echo "<h3>Student Details</h3><br>";
								$sql1 = "SELECT * from result where EID='{$_POST["term_id"]}' and CID='{$_SESSION["S_CID"]}' and STU_ID= '{$_SESSION["SID"]}'";
	              $re1=$db->query($sql1);
                $sql3 = "SELECT Tot_Marks,Percentage from exam where EID = '{$_POST["term_id"]}'";
                $re3=$db->query($sql3);
                $r3=$re3->fetch_assoc();
	              if($re1->num_rows>0 && $re3->num_rows>0)
								{

									echo '
										<table border="1px">
										<tr>
											<th>S.No</th>
											<th>Subject</th>
                      <th>MARK</th>
                      <th>Total Marks</th>
                      <th>Percentage</th>
                      <th>Grade</th>
                      <th>Remark</th>
										</tr>


									';
									$i=0;
									while($r1=$re1->fetch_assoc())
									{
										$i++;
                    $sql2 = "SELECT SNAME from sub where SID = '{$r1["SID"]}'";
    	              $re2=$db->query($sql2);

    	              if($re2->num_rows>0)
    								{

                      $r2=$re2->fetch_assoc();


                      function in_range($number, $min, $max)
                      {
                           $inclusive = FALSE;
                          if (is_numeric($number))
                          {
                              if(($number >= $min && $number <= $max))
                              {
                                $inclusive = TRUE;
                              }
                          }

                          return $inclusive;
                      }
                      if(in_range($r1["MARKS"],0,32))
                      {
                        $grade = 'F';
                      }
                      elseif(in_range($r1["MARKS"],33,39))
                      {
                        $grade = 'D';
                      }
                      elseif(in_range($r1["MARKS"],40,49))
                      {
                        $grade = 'C';
                      }
                      elseif(in_range($r1["MARKS"],50,59))
                      {
                        $grade = 'B';
                      }
                      elseif(in_range($r1["MARKS"],60,69))
                      {
                        $grade = "A-";
                      }
                      elseif(in_range($r1["MARKS"],70,79))
                      {
                        $grade = "A";
                      }
                      elseif(in_range($r1["MARKS"],80,100))
                      {
                        $grade = "A+";
                      }
                      else{
                        $grade = "Error";
                      }

                      echo "
  										<tr>
  											<td>{$i}</td>
  											<td>{$r2["SNAME"]}</td>
                        <td>{$r1["MARKS"]}</td>
                        <td>{$r3["Tot_Marks"]}</td>
                        <td>{$r3["Percentage"]}%</td>
                        <td>{$grade}</td>
                        <td>{$r1["EVAL"]}</td>



  										</tr>
  										";

                    }

									}

								}
							else
							{
								echo "No record Found";
							}
								echo "</table>";
							}


						?>

					</div>
				</div>


			</div>

				<?php include"footer.php";?>
	</body>
</html>
