<div class="navbar">

			<ul class="list">
				<b style="color:white;float:left;line-height:50px;margin-left:15px;font-family:Cooper Black;">
				School Evaluation System</b>
			<?php
				if(isset($_SESSION["TID"]))
				{
					echo'

						<li><a href="home.html">Home</a></li>
						<li><a href="logout.php">Logout</a></li>
							';
				}
				
			?>

			</ul>
		</div>
